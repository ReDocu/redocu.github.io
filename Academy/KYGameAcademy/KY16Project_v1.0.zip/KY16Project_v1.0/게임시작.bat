@echo off
REM ============================================================
REM  KY16 Project - C++ Game Collection launcher
REM  chcp 949 : show Korean text correctly
REM  cd %~dp0 : make save_point.txt (save/load) work
REM ============================================================
chcp 949 >nul
title KY16 Project - C++ Game Collection (9/2 - 9/27)
cd /d "%~dp0"
KY16Project.exe
